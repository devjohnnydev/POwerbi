import pandas as pd, json, glob, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
for f in glob.glob('/usr/share/fonts/opentype/inter/Inter-*.otf'): fm.fontManager.addfont(f)
plt.rcParams['font.family']='Inter'
v=pd.read_pickle('facil.pkl'); G=json.load(open('gabarito_facil.json',encoding='utf-8')); T=G['total']
TEAL,ORG,NAVY,BG='#0F766E','#F59E0B','#1E293B','#F1F5F4'
brl=lambda x:f'R$ {x:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
f=plt.figure(figsize=(19.2,10.8),dpi=100,facecolor=BG)
f.patches.append(plt.Rectangle((0,.98),1,.02,transform=f.transFigure,color=TEAL))
f.text(.03,.925,'Pet Feliz · Vendas do 1º semestre de 2026',fontsize=30,weight='bold',color=NAVY); f.text(.03,.895,'Dashboard da versão guiada · dados fictícios',fontsize=14,color='#64748B')
def card(x,lab,val,col):
    a=f.add_axes([x,.74,.215,.13]); a.set_facecolor('white'); a.set_xticks([]); a.set_yticks([])
    for s in a.spines.values(): s.set_color('#E2E8F0')
    a.add_patch(plt.Rectangle((0,0),.012,1,color=col,transform=a.transAxes)); a.text(.07,.68,lab,fontsize=14,color='#64748B',transform=a.transAxes); a.text(.07,.22,val,fontsize=27,weight='bold',color=NAVY,transform=a.transAxes)
card(.03,'Faturamento',brl(T['faturamento']),TEAL); card(.26,'Lucro',brl(T['lucro']),NAVY); card(.49,'Margem de Lucro',f"{T['margem']:.2f}%".replace('.',','),ORG); card(.72,'Pedidos · Ticket Médio',f"{T['pedidos']} · {brl(T['ticket'])}",TEAL)
def panel(r,t):
    a=f.add_axes(r); a.set_facecolor('white'); a.set_title(t,loc='left',fontsize=15,weight='bold',color=NAVY,pad=12)
    for s in ['top','right']: a.spines[s].set_visible(False)
    for s in ['left','bottom']: a.spines[s].set_color('#CBD5E1')
    a.tick_params(labelsize=12,colors='#475569'); return a
mes=['Jan','Fev','Mar','Abr','Mai','Jun']
a=panel([.06,.07,.43,.58],'Faturamento por mês'); y=[G['mes'][str(i)]['faturamento'] for i in range(1,7)]
a.plot(mes,y,color=TEAL,lw=4,marker='o'); a.yaxis.set_major_formatter(lambda x,p:f'{x/1000:.0f} mil'); a.grid(axis='y',color='#E2E8F0')
for i,vv in enumerate(y): a.text(i,vv+400,f'{vv/1000:.1f} mil',ha='center',fontsize=11,color=NAVY)
a.set_ylim(min(y)*.8,max(y)*1.12)
a=panel([.60,.40,.37,.25],'Faturamento por categoria'); c=pd.Series({k:x['faturamento'] for k,x in G['cat'].items()}).sort_values()
a.barh(c.index,c.values,color=TEAL); a.set_xticks([]); a.set_xlim(0,c.max()*1.35)
for i,x in enumerate(c.values): a.text(x,i,f'  R$ {x/1000:.1f} mil',va='center',fontsize=11)
a=panel([.60,.07,.37,.25],'Lucro por loja'); l=pd.Series({k:x['lucro'] for k,x in G['loja'].items()}).sort_values()
a.barh(l.index,l.values,color=ORG); a.set_xticks([]); a.set_xlim(0,l.max()*1.35)
for i,x in enumerate(l.values): a.text(x,i,f'  R$ {x/1000:.1f} mil',va='center',fontsize=11)
f.savefig('dash_facil.png',facecolor=BG)
