import numpy as np, pandas as pd, json, os
from datetime import date, timedelta
R=np.random.default_rng(141)
OUT='/home/claude/work/aula15/pacote_facil'; os.makedirs(OUT,exist_ok=True)
lojas=pd.DataFrame([(1,'Paulista','São Paulo','SP'),(2,'Moema','São Paulo','SP'),(3,'Campinas','Campinas','SP'),(4,'Santos','Santos','SP')],columns=['CodLoja','NomeLoja','Cidade','UF'])
lojas.to_csv(f'{OUT}/Lojas.txt',sep='\t',index=False,encoding='utf-8')
prod=pd.DataFrame([('P01','Ração Cães Adultos 15kg','Ração',86.74,139.90),('P02','Ração Gatos Castrados 10kg','Ração',81.84,129.90),('P03','Petisco Dental Cães 150g','Ração',12.45,24.90),
('P04','Bolinha de Borracha','Brinquedos',5.96,14.90),('P05','Arranhador Torre','Brinquedos',82.45,149.90),('P06','Shampoo Neutro 500ml','Higiene',13.46,29.90),
('P07','Tapete Higiênico 30un','Higiene',31.15,59.90),('P08','Coleira Ajustável M','Acessórios',17.56,39.90),('P09','Caminha Pet M','Acessórios',72.74,129.90),
('P10','Antipulgas Cães 10-20kg','Farmácia',53.94,89.90),('P11','Vermífugo Gatos','Farmácia',20.75,39.90),('P12','Comedouro Inox','Acessórios',16.40,34.90)],
columns=['SKU','Produto','Categoria','CustoUnit','PrecoLista'])
prod.to_excel(f'{OUT}/Produtos.xlsx',sheet_name='Produtos',index=False)
w=np.array([3,3,2,1.5,1,2,2,1.5,1,1.5,1.5,1.5]); w=w/w.sum()
peso={1:1.4,2:1.2,3:1.0,4:.8}; saz={1:.9,2:.85,3:1.0,4:1.05,5:1.15,6:1.1}
rows=[]; pid=1000
for m in range(1,7):
    last=(date(2026,m+1,1) if m<12 else date(2027,1,1))-timedelta(days=1)
    for cod,pl in peso.items():
        for _ in range(int(R.poisson(26*pl*saz[m]))):
            pid+=1; d=date(2026,m,1)+timedelta(days=int(R.integers(0,last.day)))
            k=int(R.choice([1,2,3],p=[.5,.35,.15]))
            for s in R.choice(12,size=k,replace=False,p=w):
                p=prod.iloc[s]; q=int(R.choice([1,2,3],p=[.65,.25,.10])) if p.PrecoLista<60 else int(R.choice([1,2],p=[.9,.1]))
                rows.append((pid,d,cod,p.SKU,q,p.PrecoLista,float(R.choice([0,.05,.10],p=[.6,.25,.15]))))
v=pd.DataFrame(rows,columns=['IDPedido','Data','CodLoja','SKU','Qtd','PrecoUnit','Desconto'])
v=v.sort_values(['Data','IDPedido']).reset_index(drop=True)
o=v.copy(); o['Data']=pd.to_datetime(o.Data).dt.strftime('%d/%m/%Y'); o['PrecoUnit']=o.PrecoUnit.map(lambda x:f'{x:.2f}'.replace('.',',')); o['Desconto']=o.Desconto.map(lambda x:f'{x:.2f}'.replace('.',','))
o.to_csv(f'{OUT}/Vendas.csv',sep=';',index=False,encoding='utf-8')
# gabarito
v['Data']=pd.to_datetime(v.Data); v=v.merge(prod,on='SKU').merge(lojas,on='CodLoja')
v['Fat']=v.Qtd*v.PrecoUnit*(1-v.Desconto); v['Custo']=v.Qtd*v.CustoUnit
def met(g): 
    f=g.Fat.sum(); l=f-g.Custo.sum(); p=g.IDPedido.nunique(); return dict(faturamento=round(f,2),custo=round(g.Custo.sum(),2),lucro=round(l,2),margem=round(l/f*100,2),pedidos=int(p),ticket=round(f/p,2),qtd=int(g.Qtd.sum()))
G={'linhas_vendas':len(v),'linhas_lojas':4,'linhas_produtos':12,'linhas_calendario':365,'total':met(v)}
G['mes']={m:met(v[v.Data.dt.month==m]) for m in range(1,7)}
G['loja']={l:met(g) for l,g in v.groupby('NomeLoja')}
G['cat']={c:met(g) for c,g in v.groupby('Categoria')}
G['qtd_loja']={l:int(g.Qtd.sum()) for l,g in v.groupby('NomeLoja')}; G['qtd_cat']={c:int(g.Qtd.sum()) for c,g in v.groupby('Categoria')}; G['qtd_mes']={m:int(g.Qtd.sum()) for m,g in v.groupby(v.Data.dt.month)}
faixa=prod.PrecoLista.map(lambda x:'Econômico' if x<30 else 'Intermediário' if x<100 else 'Premium'); G['faixas']=faixa.value_counts().to_dict()
G['fat_faixa']={f:round(v[v.SKU.isin(prod.SKU[faixa==f])].Fat.sum(),2) for f in faixa.unique()}
G['cruz_santos_jun']=met(v[(v.NomeLoja=='Santos')&(v.Data.dt.month==6)]); G['cruz_moema_racao']=met(v[(v.NomeLoja=='Moema')&(v.Categoria=='Ração')])
G['top_produto']=v.groupby('Produto').Fat.sum().sort_values(ascending=False).head(3).round(2).to_dict()
json.dump(G,open('/home/claude/work/aula15/gabarito_facil.json','w'),ensure_ascii=False,indent=1); v.to_pickle('/home/claude/work/aula15/facil.pkl')
print(json.dumps({k:G[k] for k in ['linhas_vendas','total','faixas','fat_faixa','cruz_santos_jun','cruz_moema_racao','qtd_loja','top_produto']},ensure_ascii=False,indent=1)); print(G['mes'][3],G['loja']['Santos'],G['cat']['Ração'])
