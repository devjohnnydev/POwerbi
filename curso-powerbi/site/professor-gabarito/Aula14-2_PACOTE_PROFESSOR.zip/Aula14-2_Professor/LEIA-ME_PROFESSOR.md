# Pacote do professor · Aula 14.2 (projeto final guiado)
Gabarito em HTML e XLSX, código M, calendário, 3 colunas calculadas e 5 medidas (`DAX/`), scripts que regeram os dados.
Números recalculados em Python; M e DAX não foram executados no Power BI Desktop. Rode a solução uma vez antes de liberar.
