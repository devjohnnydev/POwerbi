import pandas as pd, numpy as np, json, glob
P='pacote_aluno'
raw=pd.concat([pd.read_csv(f,sep=';',dtype=str) for f in sorted(glob.glob(P+'/Vendas/*.csv'))])
pr=pd.read_excel(P+'/Produtos.xlsx',header=3).set_index('SKU')
def prep(df,trim=True):
    df=df.copy()
    if trim: df['SKU']=df.SKU.str.strip().str.upper()
    df['Data']=pd.to_datetime(df.Data,format='%d/%m/%Y')
    for c in ['PrecoUnit','Desconto']: df[c]=df[c].str.replace(',','.').astype(float)
    df['Qtd']=df.Qtd.astype(int); df['CodLoja']=df.CodLoja.astype(int)
    df['Fat']=df.Qtd*df.PrecoUnit*(1-df.Desconto); df['Custo']=df.SKU.map(pr.CustoUnit); df['CMV']=df.Qtd*df.Custo.fillna(0)
    return df
ok=prep(raw).drop_duplicates(); ok=ok[ok.CodLoja!=99]
E={}
E['certo_fat_total']=round(ok.Fat.sum(),2)
nd=prep(raw); nd=nd[nd.CodLoja!=99]; E['sem_remover_duplicatas_fat_total']=round(nd.Fat.sum(),2); E['sem_remover_duplicatas_linhas']=len(nd)
nt=prep(raw).drop_duplicates(); E['sem_remover_loja_teste_fat_total']=round(nt.Fat.sum(),2); E['sem_remover_loja_teste_linhas']=len(nt)
E['sem_nada_fat_total']=round(prep(raw).Fat.sum(),2)
nk=prep(raw,trim=False).drop_duplicates(); nk=nk[nk.CodLoja!=99]
E['sem_padronizar_sku_linhas_sem_custo']=int(nk.Custo.isna().sum()); E['sem_padronizar_sku_cmv_2026']=round(nk[nk.Data.dt.year==2026].CMV.sum(),2); E['certo_cmv_2026']=round(ok[ok.Data.dt.year==2026].CMV.sum(),2)
a=ok[ok.Data.dt.year==2026]
E['pedidos_2026']=int(a.IDPedido.nunique()); E['clientes_2026_com_vazio']=int(a.IDCliente.nunique(dropna=False)); E['clientes_2026_certo']=int(a.IDCliente.nunique())
E['soma_preco_x_qtd_sem_desconto_2026']=round((a.Qtd*a.PrecoUnit).sum(),2)
E['fat_2026_media_em_vez_de_soma_ticket_errado_linha']=round(a.Fat.sum()/len(a),2)
E['linhas_2026']=len(a)
# ranking lojas 2026
r=a.groupby('CodLoja').Fat.sum().rank(ascending=False).astype(int).to_dict(); E['rank_2026']={int(k):int(v) for k,v in r.items()}
mt=pd.read_excel(P+'/Metas_2026.xlsx'); E['meta_santos_ano_cheio']=int(mt[mt.CodLoja==4].iloc[0,2:].sum()); E['meta_barra_ano_cheio']=int(mt[mt.CodLoja==5].iloc[0,2:].sum())
json.dump(E,open('erros_comuns.json','w'),indent=1,ensure_ascii=False); print(json.dumps(E,indent=1,ensure_ascii=False))
