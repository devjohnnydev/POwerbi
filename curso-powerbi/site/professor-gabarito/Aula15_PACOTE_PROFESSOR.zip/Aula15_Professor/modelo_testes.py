import pandas as pd, numpy as np, json, glob
P='pacote_aluno'
v=pd.concat([pd.read_csv(f,sep=';',dtype=str) for f in sorted(glob.glob(P+'/Vendas/*.csv'))]).drop_duplicates()
v['SKU']=v.SKU.str.strip().str.upper(); v['Data']=pd.to_datetime(v.Data,format='%d/%m/%Y')
for c in ['PrecoUnit','Desconto']: v[c]=v[c].str.replace(',','.').astype(float)
v['Qtd']=v.Qtd.astype(int); v['CodLoja']=v.CodLoja.astype(int); v=v[v.CodLoja!=99]
pr=pd.read_excel(P+'/Produtos.xlsx',header=3)
lj=pd.read_csv(P+'/Lojas.txt',sep='\t'); lj=lj[lj.CodLoja!=99]
cl=pd.read_csv(P+'/Clientes.csv',sep=';',encoding='cp1252')
v=v.merge(pr[['SKU','Categoria','CustoUnit','Produto']],on='SKU',how='left').merge(lj[['CodLoja','NomeLoja','Regiao']],on='CodLoja',how='left').merge(cl[['IDCliente','Sexo']],on='IDCliente',how='left')
v['Fat']=v.Qtd*v.PrecoUnit*(1-v.Desconto); v['CMV']=v.Qtd*v.CustoUnit
dv=json.load(open(P+'/Devolucoes.json',encoding='utf-8'))['devolucoes']
d=pd.DataFrame([{'pedido':x['pedido'],'data':pd.Timestamp(x['dataDevolucao']),'loja':x['loja'],'sku':i['sku'],'valor':i['valorReembolsado'],'qtd':i['qtd']} for x in dv for i in x['itens']])
d=d.merge(pr[['SKU','Categoria']],left_on='sku',right_on='SKU',how='left').merge(lj[['CodLoja','NomeLoja']],left_on='loja',right_on='CodLoja',how='left')
mt=pd.read_excel(P+'/Metas_2026.xlsx').melt(id_vars=['CodLoja','Loja'],var_name='Mes',value_name='Meta')
mes=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']; mt['m']=mt.Mes.map({k:i+1 for i,k in enumerate(mes)}); mt=mt.merge(lj[['CodLoja','NomeLoja']],on='CodLoja')
R=lambda s:{str(k):round(float(x),2) for k,x in s.items()}
T={}
# orfãos
T['orfaos']={'vendas_sem_produto':int(v.Categoria.isna().sum()),'vendas_sem_loja':int(v.NomeLoja.isna().sum()),'vendas_sem_cliente_cadastrado':int(v.Sexo.isna().sum()),
 'vendas_com_id_cliente_vazio':int(v.IDCliente.isna().sum()),'vendas_com_id_inexistente':int((v.Sexo.isna()&v.IDCliente.notna()).sum()),
 'dev_sem_produto':int(d.Categoria.isna().sum()),'dev_sem_loja':int(d.NomeLoja.isna().sum()),'metas_sem_loja':int(mt.NomeLoja.isna().sum()),
 'chaves_dup_lojas':int(len(lj)-lj.CodLoja.nunique()),'chaves_dup_produtos':int(len(pr)-pr.SKU.nunique()),'chaves_dup_clientes':int(len(cl)-cl.IDCliente.nunique()),
 'linhas_dLojas':len(lj),'linhas_dProdutos':len(pr),'linhas_dClientes':len(cl),'datas_vendas_fora_calendario':int(((v.Data<'2025-01-01')|(v.Data>'2026-12-31')).sum())}
T['fat_por_loja_total']=R(v.groupby('NomeLoja').Fat.sum().sort_values(ascending=False))
T['fat_por_categoria_total']=R(v.groupby('Categoria').Fat.sum().sort_values(ascending=False))
T['fat_por_ano']=R(v.groupby(v.Data.dt.year).Fat.sum())
T['fat_por_regiao_total']=R(v.groupby('Regiao').Fat.sum())
sx=v.assign(S=v.Sexo.fillna('(Em branco)')).groupby('S').Fat.sum(); T['fat_por_sexo_total']=R(sx)
T['dev_por_loja_total']=R(d.groupby('NomeLoja').valor.sum().sort_values(ascending=False))
T['dev_por_categoria_total']=R(d.groupby('Categoria').valor.sum().sort_values(ascending=False))
T['dev_por_ano']=R(d.groupby(d.data.dt.year).valor.sum())
T['dev_por_mes_2026']={mes[k-1]:round(float(x),2) for k,x in d[d.data.dt.year==2026].groupby(d.data.dt.month).valor.sum().items()}
T['meta_total_2026_ano_cheio']=int(mt.Meta.sum()); T['meta_jan_ago']=int(mt[mt.m<=8].Meta.sum())
T['meta_por_loja_jan_ago']={k:int(x) for k,x in mt[mt.m<=8].groupby('NomeLoja').Meta.sum().sort_values(ascending=False).items()}
T['meta_por_mes_total']={mes[k-1]:int(x) for k,x in mt.groupby('m').Meta.sum().items()}
a=v[v.Data.dt.year==2026]
T['fat_2026_por_loja']=R(a.groupby('NomeLoja').Fat.sum().sort_values(ascending=False))
T['fat_por_mes_2026']={mes[k-1]:round(float(x),2) for k,x in a.groupby(a.Data.dt.month).Fat.sum().items()}
T['fat_por_mes_2025']={mes[k-1]:round(float(x),2) for k,x in v[v.Data.dt.year==2025].groupby(v.Data.dt.month).Fat.sum().items()}
# testes cruzados
def bloco(l=None,c=None):
    x=a; dd=d[d.data.dt.year==2026]; m=mt[mt.m<=8]
    if l: x=x[x.NomeLoja==l]; dd=dd[dd.NomeLoja==l]; m=m[m.NomeLoja==l]
    if c: x=x[x.Categoria==c]; dd=dd[dd.Categoria==c]
    return {'faturamento_2026':round(x.Fat.sum(),2),'devolucoes_2026':round(dd.valor.sum(),2),'meta_jan_ago':int(m.Meta.sum())}
T['cruzado_santos']=bloco('Pet Feliz Santos'); T['cruzado_racao']=bloco(None,'Ração'); T['cruzado_santos_racao']=bloco('Pet Feliz Santos','Ração')
T['linhas_fVendas']=len(v); T['linhas_fDevolucoes']=len(d); T['linhas_fMetas']=len(mt)
T['qtd_por_loja_total']={k:int(x) for k,x in v.groupby('NomeLoja').Qtd.sum().sort_values(ascending=False).items()}
T['qtd_por_categoria_total']={k:int(x) for k,x in v.groupby('Categoria').Qtd.sum().sort_values(ascending=False).items()}
T['qtd_por_ano']={str(k):int(x) for k,x in v.groupby(v.Data.dt.year).Qtd.sum().items()}
T['qtd_total']=int(v.Qtd.sum())
T['qtd_sem_cliente']=int(v[v.Sexo.isna()].Qtd.sum())
T['meta_por_loja_ano_cheio']={k:int(x) for k,x in mt.groupby('NomeLoja').Meta.sum().sort_values(ascending=False).items()}
T['dev_por_mes_2025_2026_mai26']=round(float(d[(d.data.dt.year==2026)&(d.data.dt.month==5)].valor.sum()),2)
json.dump(T,open('gabarito_modelo.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(json.dumps({k:T[k] for k in ['orfaos','fat_por_ano','dev_por_ano','fat_por_sexo_total','cruzado_santos','cruzado_racao','cruzado_santos_racao','meta_total_2026_ano_cheio','meta_jan_ago','dev_por_loja_total','dev_por_categoria_total']},ensure_ascii=False,indent=1))
