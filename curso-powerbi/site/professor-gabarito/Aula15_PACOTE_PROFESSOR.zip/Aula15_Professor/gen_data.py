import numpy as np, pandas as pd, json, os, random
from datetime import date, timedelta
R = np.random.default_rng(2026)
random.seed(2026)
OUT = '/home/claude/work/aula15/pacote_aluno'
for d in ['', '/Vendas', '/Novos_Dados']:
    os.makedirs(OUT + d, exist_ok=True)

# ---------------- LOJAS ----------------
lojas = pd.DataFrame([
    (1, 'Pet Feliz Paulista', 'São Paulo', 'SP', 'Sudeste', 'Marina Costa', '2019-03-10'),
    (2, 'Pet Feliz Moema', 'São Paulo', 'SP', 'Sudeste', 'Rafael Lima', '2020-08-22'),
    (3, 'Pet Feliz Campinas', 'Campinas', 'SP', 'Sudeste', 'Juliana Prado', '2021-02-15'),
    (4, 'Pet Feliz Santos', 'Santos', 'SP', 'Sudeste', 'Carlos Menezes', '2021-11-05'),
    (5, 'Pet Feliz Barra', 'Rio de Janeiro', 'RJ', 'Sudeste', 'Patrícia Souza', '2022-06-18'),
    (6, 'Pet Feliz Savassi', 'Belo Horizonte', 'MG', 'Sudeste', 'Thiago Alves', '2023-01-30'),
    (7, 'Pet Feliz Batel', 'Curitiba', 'PR', 'Sul', 'Fernanda Rocha', '2023-09-12'),
    (8, 'Pet Feliz Moinhos', 'Porto Alegre', 'RS', 'Sul', 'Bruno Teixeira', '2025-06-02'),
    (99, 'LOJA TESTE', 'São Paulo', 'SP', 'Sudeste', 'TI', '2025-01-01'),
], columns=['CodLoja', 'NomeLoja', 'Cidade', 'UF', 'Regiao', 'Gerente', 'DataAbertura'])
lojas.to_csv(f'{OUT}/Lojas.txt', sep='\t', index=False, encoding='utf-8')

# ---------------- PRODUTOS ----------------
cats = {
    'Ração': [('Ração Premium Cães Adultos 15kg', 'Naturalle', 139.9, .62), ('Ração Premium Cães Filhotes 10kg', 'Naturalle', 119.9, .62),
              ('Ração Gatos Castrados 10kg', 'FelinoMax', 129.9, .63), ('Ração Gatos Filhotes 3kg', 'FelinoMax', 54.9, .60),
              ('Ração Super Premium Cães 15kg', 'Golden Pet', 219.9, .66), ('Sachê Gatos Carne 85g', 'FelinoMax', 3.9, .55),
              ('Ração Cães Porte Pequeno 7kg', 'Naturalle', 89.9, .61), ('Petisco Dental Cães 150g', 'Golden Pet', 24.9, .50)],
    'Brinquedos': [('Bolinha de Borracha', 'PlayDog', 14.9, .40), ('Corda com Nó', 'PlayDog', 19.9, .42), ('Arranhador Torre', 'MiauHouse', 149.9, .55),
                   ('Ratinho de Pelúcia', 'MiauHouse', 9.9, .38), ('Mordedor Osso', 'PlayDog', 22.9, .41), ('Varinha com Penas', 'MiauHouse', 12.9, .39)],
    'Higiene': [('Shampoo Neutro 500ml', 'Pelo&Brilho', 29.9, .45), ('Condicionador 500ml', 'Pelo&Brilho', 31.9, .45), ('Tapete Higiênico 30un', 'CleanPet', 59.9, .52),
                ('Areia Sanitária 12kg', 'CleanPet', 34.9, .54), ('Escova Removedora de Pelos', 'Pelo&Brilho', 27.9, .43), ('Colônia Pet 120ml', 'Pelo&Brilho', 24.9, .40)],
    'Acessórios': [('Coleira Ajustável M', 'DogStyle', 39.9, .44), ('Guia Retrátil 5m', 'DogStyle', 69.9, .48), ('Caminha Pet M', 'ConfortPet', 129.9, .56),
                   ('Comedouro Inox', 'ConfortPet', 34.9, .47), ('Bebedouro Fonte', 'ConfortPet', 189.9, .58), ('Caixa de Transporte', 'DogStyle', 159.9, .57),
                   ('Roupinha Inverno P', 'DogStyle', 49.9, .46)],
    'Farmácia': [('Antipulgas Cães 10-20kg', 'VetCare', 89.9, .60), ('Vermífugo Gatos', 'VetCare', 39.9, .52), ('Suplemento Articular', 'VetCare', 99.9, .55),
                 ('Antipulgas Gatos', 'VetCare', 79.9, .59), ('Colírio Pet 10ml', 'VetCare', 29.9, .45)],
}
rows = []
n = 1
for c, lst in cats.items():
    for nome, marca, preco, pc in lst:
        rows.append((f'PF{n:04d}', nome, c, marca, round(preco * pc, 2), preco))
        n += 1
prod = pd.DataFrame(rows, columns=['SKU', 'Produto', 'Categoria', 'Marca', 'CustoUnit', 'PrecoLista'])
# Excel com linhas de título (pegadinha: cabeçalho na linha 4)
with pd.ExcelWriter(f'{OUT}/Produtos.xlsx', engine='openpyxl') as w:
    prod.to_excel(w, sheet_name='Cadastro', index=False, startrow=3)
    ws = w.sheets['Cadastro']
    ws['A1'] = 'PET FELIZ — CADASTRO DE PRODUTOS'
    ws['A2'] = 'Atualizado em 30/09/2026 — Departamento de Compras'
    for col, wd in zip('ABCDEF', [10, 36, 14, 14, 11, 11]):
        ws.column_dimensions[col].width = wd

# ---------------- CLIENTES ----------------
nomes = ['Ana', 'Bruno', 'Carla', 'Diego', 'Elisa', 'Fábio', 'Gabriela', 'Hugo', 'Isabela', 'João', 'Karina', 'Lucas', 'Mariana', 'Nelson', 'Olívia',
         'Paulo', 'Quésia', 'Rodrigo', 'Sônia', 'Tiago', 'Úrsula', 'Vítor', 'Wagner', 'Yasmin', 'Zélia', 'André', 'Beatriz', 'Cláudio', 'Letícia', 'Márcio']
sob = ['Silva', 'Santos', 'Oliveira', 'Souza', 'Pereira', 'Lima', 'Carvalho', 'Ribeiro', 'Gonçalves', 'Almeida', 'Araújo', 'Fernandes', 'Barbosa', 'Nascimento', 'Cardoso']
NC = 3200
cli = []
for i in range(1, NC + 1):
    cid = f'C{i:05d}'
    nm = f'{R.choice(nomes)} {R.choice(sob)} {R.choice(sob)}'
    cad = date(2022, 1, 1) + timedelta(days=int(R.integers(0, 1700)))
    cli.append((cid, nm, R.choice(['F', 'M']), R.choice(lojas.Cidade[:8]), cad.strftime('%d/%m/%Y')))
clientes = pd.DataFrame(cli, columns=['IDCliente', 'NomeCliente', 'Sexo', 'Cidade', 'DataCadastro'])
clientes.to_csv(f'{OUT}/Clientes.csv', sep=';', index=False, encoding='cp1252')

# ---------------- VENDAS ----------------
months = [(2025, m) for m in range(1, 13)] + [(2026, m) for m in range(1, 9)] + [(2026, 9)]
sazon = {1: .9, 2: .85, 3: .95, 4: 1.0, 5: 1.15, 6: 1.0, 7: .95, 8: 1.0, 9: 1.05, 10: 1.1, 11: 1.25, 12: 1.4}
peso_loja = {1: 1.5, 2: 1.3, 3: 1.0, 4: .8, 5: 1.1, 6: .9, 7: .85, 8: .7}
pesos_prod = np.array([3 if c == 'Ração' else 2 if c in ('Higiene', 'Farmácia') else 1.5 for c in prod.Categoria])
pesos_prod = pesos_prod / pesos_prod.sum()
all_lines = []
pid = 100000
for (y, m) in months:
    t = (y - 2025) * 12 + m
    base = 55 * (1 + 0.018 * t) * sazon[m]  # pedidos/loja/mês fator
    first = date(y, m, 1)
    last = (date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1))
    nd = last.day
    for cod, pl in peso_loja.items():
        if cod == 8 and (y, m) < (2025, 6):
            continue
        npedidos = int(R.poisson(base * pl * 0.9))
        for _ in range(npedidos):
            pid += 1
            d = first + timedelta(days=int(R.integers(0, nd)))
            # fim de semana vende mais
            cl = f'C{int(R.integers(1, NC + 1)):05d}' if R.random() > .12 else ''
            k = int(R.choice([1, 2, 3, 4], p=[.45, .3, .17, .08]))
            skus = R.choice(len(prod), size=k, replace=False, p=pesos_prod)
            for s in skus:
                p = prod.iloc[s]
                promo = R.random() < .18
                pu = round(p.PrecoLista * (0.9 if promo else 1.0), 2)
                qtd = int(R.choice([1, 2, 3, 4, 5], p=[.6, .22, .1, .05, .03])) if p.PrecoLista < 60 else int(R.choice([1, 2], p=[.88, .12]))
                desc = float(R.choice([0, 0, 0, .05, .1], p=[.5, .2, .1, .12, .08]))
                all_lines.append((pid, d, cod, cl, p.SKU, qtd, pu, desc))
    # linhas de teste (loja 99)
    for _ in range(12):
        pid += 1
        p = prod.iloc[int(R.integers(0, len(prod)))]
        all_lines.append((pid, first + timedelta(days=int(R.integers(0, nd))), 99, 'C00001', p.SKU, 1, p.PrecoLista, 0.0))
V = pd.DataFrame(all_lines, columns=['IDPedido', 'Data', 'CodLoja', 'IDCliente', 'SKU', 'Qtd', 'PrecoUnit', 'Desconto'])
V['Data'] = pd.to_datetime(V['Data'])
V.to_pickle('/home/claude/work/aula15/vendas_limpas_com_teste.pkl')

# ---------------- DEVOLUÇÕES (JSON aninhado) ----------------
leg = V[V.CodLoja != 99]
ped = leg.groupby('IDPedido').agg(Data=('Data', 'first'), CodLoja=('CodLoja', 'first')).reset_index()
amostra = ped.sample(frac=.025, random_state=7)
devs = []
motivos = ['Produto danificado', 'Arrependimento', 'Produto errado', 'Validade próxima']
did = 5000
for _, r in amostra.iterrows():
    linhas = leg[leg.IDPedido == r.IDPedido]
    ln = linhas.sample(n=1, random_state=int(r.IDPedido)).iloc[0]
    q = 1
    val = round(q * ln.PrecoUnit * (1 - ln.Desconto), 2)
    dd = r.Data + pd.Timedelta(days=int(R.integers(1, 10)))
    if dd > pd.Timestamp('2026-08-31') and r.Data <= pd.Timestamp('2026-08-31'):
        dd = pd.Timestamp('2026-08-31')
    did += 1
    devs.append({'idDevolucao': did, 'pedido': int(r.IDPedido), 'dataDevolucao': dd.strftime('%Y-%m-%d'),
                 'loja': int(r.CodLoja), 'motivo': str(R.choice(motivos)),
                 'itens': [{'sku': ln.SKU, 'qtd': q, 'valorReembolsado': val}]})
dev_set = [d for d in devs if d['dataDevolucao'] <= '2026-08-31']
dev_set_df = pd.DataFrame([{'pedido': d['pedido'], 'data': pd.Timestamp(d['dataDevolucao']), 'loja': d['loja'], 'valor': d['itens'][0]['valorReembolsado'], 'sku': d['itens'][0]['sku']} for d in dev_set])
json.dump({'empresa': 'Pet Feliz', 'periodo': '2025-01 a 2026-08', 'devolucoes': dev_set},
          open(f'{OUT}/Devolucoes.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
dev_set_df.to_pickle('/home/claude/work/aula15/dev.pkl')

# ---------------- METAS (larga) ----------------
mes_pt = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
vv = V[(V.CodLoja != 99)].copy()
vv['Liq'] = vv.Qtd * vv.PrecoUnit * (1 - vv.Desconto)
ref = vv[vv.Data.dt.year == 2025].groupby(['CodLoja', vv.Data.dt.month]).Liq.sum().unstack().fillna(0)
MULT = {1:1.38,2:1.30,3:1.42,4:1.12,5:1.28,6:1.30,7:1.33,8:1.10}
mt = []
for cod in range(1, 9):
    row = {'CodLoja': cod, 'Loja': lojas.set_index('CodLoja').loc[cod, 'NomeLoja']}
    for i, mn in enumerate(mes_pt, 1):
        b = ref.loc[cod, i] if (cod in ref.index and i in ref.columns and ref.loc[cod, i] > 0) else ref.loc[cod].replace(0, np.nan).mean()
        row[mn] = int(round(b * MULT[cod] / 100) * 100)
    mt.append(row)
metas = pd.DataFrame(mt)
with pd.ExcelWriter(f'{OUT}/Metas_2026.xlsx', engine='openpyxl') as w:
    metas.to_excel(w, sheet_name='Metas', index=False)
metas.to_pickle('/home/claude/work/aula15/metas.pkl')

# ---------------- RUÍDO NOS CSVs de vendas ----------------
def fmt(df):
    o = df.copy()
    o['Data'] = o['Data'].dt.strftime('%d/%m/%Y')
    o['PrecoUnit'] = o['PrecoUnit'].map(lambda x: f'{x:.2f}'.replace('.', ','))
    o['Desconto'] = o['Desconto'].map(lambda x: f'{x:.2f}'.replace('.', ','))
    return o

dup_info = {}
for (y, m) in months:
    sub = V[(V.Data.dt.year == y) & (V.Data.dt.month == m)].copy()
    sub = sub.sample(frac=1, random_state=y * 100 + m).sort_values(['Data', 'IDPedido']).reset_index(drop=True)
    o = fmt(sub)
    # SKU com espaço sobrando e minúsculo em ~1%
    idx = o.sample(frac=.01, random_state=m + y).index
    o.loc[idx, 'SKU'] = o.loc[idx, 'SKU'].map(lambda s: s.lower() + ' ')
    # duplicatas exatas ~0,5%
    dups = o.sample(frac=.005, random_state=m * 3 + y)
    dup_info[(y, m)] = len(dups)
    o = pd.concat([o, dups], ignore_index=True).sample(frac=1, random_state=1).reset_index(drop=True)
    path = f'{OUT}/Novos_Dados/Vendas_2026_09.csv' if (y, m) == (2026, 9) else f'{OUT}/Vendas/Vendas_{y}_{m:02d}.csv'
    o.to_csv(path, sep=';', index=False, encoding='utf-8')
pd.Series({f'{k[0]}-{k[1]:02d}': v for k, v in dup_info.items()}).to_json('/home/claude/work/aula15/dups.json')
print('linhas V', len(V), 'pedidos', V.IDPedido.nunique(), 'devs', len(dev_set))
print(dup_info)
