import pandas as pd, numpy as np, json, glob, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
for f in glob.glob('/usr/share/fonts/opentype/inter/Inter-*.otf'): fm.fontManager.addfont(f)
plt.rcParams['font.family']='Inter'
P='pacote_aluno'
G=json.load(open('gabarito.json',encoding='utf-8'))
v=pd.concat([pd.read_csv(f,sep=';',dtype=str) for f in sorted(glob.glob(P+'/Vendas/*.csv'))]).drop_duplicates()
v['SKU']=v.SKU.str.strip().str.upper(); v['Data']=pd.to_datetime(v.Data,format='%d/%m/%Y')
for c in ['PrecoUnit','Desconto']: v[c]=v[c].str.replace(',','.').astype(float)
v['Qtd']=v.Qtd.astype(int); v['CodLoja']=v.CodLoja.astype(int); v=v[v.CodLoja!=99]
pr=pd.read_excel(P+'/Produtos.xlsx',header=3); v=v.merge(pr,on='SKU')
lj=pd.read_csv(P+'/Lojas.txt',sep='\t').set_index('CodLoja'); v['Loja']=v.CodLoja.map(lj.NomeLoja).str.replace('Pet Feliz ','')
v['Fat']=v.Qtd*v.PrecoUnit*(1-v.Desconto); v['CMV']=v.Qtd*v.CustoUnit
TEAL,ORG,NAVY,BG,GR='#0F766E','#F59E0B','#1E293B','#F1F5F4','#94A3B8'
fmt=lambda x:f'R$ {x/1000:,.0f} mil'.replace(',','.')
brl=lambda x:f'R$ {x:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
def base(title,sub):
    fig=plt.figure(figsize=(19.2,10.8),dpi=100,facecolor=BG)
    fig.text(.03,.925,title,fontsize=30,weight='bold',color=NAVY)
    fig.text(.03,.895,sub,fontsize=14,color='#64748B')
    fig.patches.append(plt.Rectangle((0,.98),1,.02,transform=fig.transFigure,color=TEAL))
    return fig
def card(fig,x,y,w,h,label,val,note=None,col=TEAL):
    ax=fig.add_axes([x,y,w,h]); ax.set_facecolor('white'); ax.set_xticks([]);ax.set_yticks([])
    for s in ax.spines.values(): s.set_color('#E2E8F0')
    ax.add_patch(plt.Rectangle((0,0),.012,1,color=col,transform=ax.transAxes))
    ax.text(.07,.72,label,fontsize=13,color='#64748B',transform=ax.transAxes)
    ax.text(.07,.30,val,fontsize=25,weight='bold',color=NAVY,transform=ax.transAxes)
    if note: ax.text(.07,.08,note,fontsize=11,color=col,transform=ax.transAxes)
def panel(fig,rect,title):
    ax=fig.add_axes(rect); ax.set_facecolor('white')
    ax.set_title(title,loc='left',fontsize=15,weight='bold',color=NAVY,pad=12)
    for s in ['top','right']: ax.spines[s].set_visible(False)
    for s in ['left','bottom']: ax.spines[s].set_color('#CBD5E1')
    ax.tick_params(colors='#475569',labelsize=11); return ax
a26=v[v.Data.dt.year==2026]; T=G['2026']
mes=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
# ---- Página 1
f=base('Pet Feliz · Visão Geral','Jan–Ago/2026 · valores líquidos de devoluções onde indicado · dados de exemplo do curso')
card(f,.03,.76,.145,.12,'Faturamento',brl(T['faturamento']),f"▲ {G['crescimento_ytd']*100:.1f}% vs mesmo período 2025".replace('.',','))
card(f,.185,.76,.145,.12,'Devoluções',brl(T['devolucoes']),None,ORG)
card(f,.34,.76,.145,.12,'Faturamento Líquido',brl(T['liquido']))
card(f,.495,.76,.145,.12,'Lucro',brl(T['lucro']),None,NAVY)
card(f,.65,.76,.145,.12,'Margem de Lucro',f"{T['margem']*100:.1f}%".replace('.',','),None,ORG)
card(f,.805,.76,.165,.12,'Ticket Médio / Pedidos',f"{brl(T['ticket'])}",f"{T['pedidos']:,} pedidos".replace(',','.'))
ax=panel(f,[.065,.07,.525,.62],'Faturamento mensal: 2026 × 2025')
m25=v[v.Data.dt.year==2025].groupby(v.Data.dt.month).Fat.sum(); m26=a26.groupby(a26.Data.dt.month).Fat.sum()
ax.plot(range(12),m25.reindex(range(1,13)).values,color=GR,lw=3,marker='o',label='2025')
ax.plot(range(8),m26.reindex(range(1,9)).values,color=TEAL,lw=4,marker='o',label='2026')
ax.set_xticks(range(12)); ax.set_xticklabels(mes); ax.yaxis.set_major_formatter(lambda x,p:f'{x/1000:.0f} mil'); ax.grid(axis='y',color='#E2E8F0'); ax.legend(frameon=False,fontsize=12)
ax=panel(f,[.69,.38,.28,.31],'Faturamento por categoria (2026)')
c=a26.groupby('Categoria').Fat.sum().sort_values(); ax.barh(c.index,c.values,color=TEAL)
for i,x in enumerate(c.values): ax.text(x,i,'  '+fmt(x),va='center',fontsize=11,color=NAVY)
ax.set_xlim(0,c.max()*1.3); ax.set_xticks([])
ax=panel(f,[.69,.07,.28,.24],'Margem bruta por categoria')
mg=a26.groupby('Categoria').apply(lambda g:1-g.CMV.sum()/g.Fat.sum()).sort_values(); ax.barh(mg.index,mg.values*100,color=ORG)
for i,x in enumerate(mg.values): ax.text(x*100,i,f'  {x*100:.1f}%'.replace('.',','),va='center',fontsize=11); 
ax.set_xlim(0,65); ax.set_xticks([])
f.savefig('dash_p1.png',facecolor=BG); plt.close(f)
# ---- Página 2: Lojas e metas
f=base('Pet Feliz · Lojas e Metas','Realizado × Meta · Jan–Ago/2026')
card(f,.03,.76,.2,.12,'Meta Jan–Ago',brl(G['meta_jan_ago_2026']),None,NAVY)
card(f,.24,.76,.2,.12,'Realizado',brl(T['faturamento']))
card(f,.45,.76,.2,.12,'% Atingimento',f"{G['atingimento_meta_ytd']*100:.1f}%".replace('.',','),'abaixo da meta',ORG)
card(f,.66,.76,.31,.12,'Lojas que bateram a meta',f"{G['loja_acima_meta']} de 8",None,TEAL)
ax=panel(f,[.085,.07,.405,.62],'% de atingimento da meta por loja')
at=pd.Series(G['atingimento_loja']).sort_values(); at.index=[i.replace('Pet Feliz ','') for i in at.index]
ax.barh(at.index,at.values*100,color=[TEAL if x>=1 else ORG for x in at.values]); ax.axvline(100,color=NAVY,ls='--')
for i,x in enumerate(at.values): ax.text(x*100+1,i,f'{x*100:.1f}%'.replace('.',','),va='center',fontsize=12,weight='bold')
ax.set_xlim(0,140); ax.set_xticks([])
ax=panel(f,[.60,.07,.37,.62],'Faturamento por loja (2026) — participação')
ls=a26.groupby('Loja').Fat.sum().sort_values()
ax.barh(ls.index,ls.values,color=NAVY)
for i,x in enumerate(ls.values): ax.text(x,i,f'  {fmt(x)}  ({x/ls.sum()*100:.1f}%)'.replace('.',',') ,va='center',fontsize=11)
ax.set_xlim(0,ls.max()*1.5); ax.set_xticks([])
f.savefig('dash_p2.png',facecolor=BG); plt.close(f)
# ---- Página 3: Produtos e clientes
f=base('Pet Feliz · Produtos e Clientes','Top produtos, regiões e comportamento de compra · 2026')
cl=G['clientes_distintos_2026']
card(f,.03,.76,.2,.12,'Clientes distintos (identificados)',f'{cl:,}'.replace(',','.'),None,TEAL)
card(f,.24,.76,.2,.12,'Pedidos',f"{T['pedidos']:,}".replace(',','.'),None,NAVY)
card(f,.45,.76,.2,.12,'Itens vendidos',f"{T['qtd']:,}".replace(',','.'),None,ORG)
card(f,.66,.76,.31,.12,'Fat. Ago/26 vs Ago/25',f"▲ {G['yoy_ago_2026']*100:.1f}%".replace('.',','),'crescimento ano contra ano',TEAL)
ax=panel(f,[.19,.07,.34,.62],'Top 10 produtos por faturamento')
t=a26.groupby('Produto').Fat.sum().sort_values().tail(10); ax.barh(t.index,t.values,color=TEAL)
for i,x in enumerate(t.values): ax.text(x,i,'  '+fmt(x),va='center',fontsize=11)
ax.set_xlim(0,t.max()*1.25); ax.set_xticks([])
ax=panel(f,[.58,.38,.39,.31],'Faturamento por região')
rg=a26.assign(R=a26.CodLoja.map(lj.Regiao)).groupby('R').Fat.sum(); ax.bar(rg.index,rg.values,color=[NAVY,ORG],width=.5)
for i,x in enumerate(rg.values): ax.text(i,x,fmt(x),ha='center',va='bottom',fontsize=12)
ax.set_yticks([]); ax.set_ylim(0,rg.max()*1.2)
ax=panel(f,[.58,.07,.39,.24],'Pedidos por mês (2026)')
pm=a26.groupby(a26.Data.dt.month).IDPedido.nunique(); ax.bar([mes[i-1] for i in pm.index],pm.values,color=TEAL)
for i,x in enumerate(pm.values): ax.text(i,x,str(x),ha='center',va='bottom',fontsize=10)
ax.set_yticks([])
f.savefig('dash_p3.png',facecolor=BG); plt.close(f)
# tema JSON
json.dump({"name":"Pet Feliz","dataColors":[TEAL,ORG,NAVY,"#38BDF8","#A3E635","#F472B6","#94A3B8","#7C3AED"],"background":"#FFFFFF","foreground":NAVY,"tableAccent":TEAL,"good":"#16A34A","bad":"#DC2626","neutral":ORG,"textClasses":{"label":{"fontFace":"Segoe UI","fontSize":11,"color":"#475569"},"title":{"fontFace":"Segoe UI Semibold","fontSize":14,"color":NAVY},"callout":{"fontFace":"Segoe UI Semibold","fontSize":28,"color":NAVY}}},open('PetFeliz_tema.json','w'),indent=1)
print('ok')
