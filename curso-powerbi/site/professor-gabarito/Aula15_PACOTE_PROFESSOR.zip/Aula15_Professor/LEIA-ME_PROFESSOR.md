# Pacote do professor · Aula 15
- `Gabarito_Professor_Aula15.html` (abra no navegador, as imagens estão em `img/`) e `Gabarito_Professor_Aula15.xlsx`: solução completa, números esperados de todas as conferências, testes do modelo, erros comuns.
- `M/*.pq`: uma consulta Power Query por tabela (mais o parâmetro `pPasta`). `DAX/medidas_e_testes.dax`: calendário, medidas e medidas de teste.
- `gabarito*.json`, `erros_comuns.json`: números em JSON. Scripts `*.py`: regeram dados e gabarito (semente fixa).
- IMPORTANTE: M e DAX não foram executados no Power BI Desktop (não há como aqui). Os números foram recalculados em Python lendo os arquivos brutos. Rode a solução uma vez antes de liberar a aula.
- Os resultados esperados ficam no HTML da aula (atributo data-a). Quem abrir o código-fonte vê as respostas.

## Ajustes sugeridos no site existente
1. Links de Anterior/Próxima das aulas 10, 12, 13 e 14 estão desencontrados (ex.: Aula 14 → aula-12). Corrigir.
2. Aula 14, 'Resumo do curso': numeração deslocada em um. Trocar 'de 14' por 'de 15' em todas as aulas e adicionar 'Próxima aula' na Aula 14.
3. Publicar `site/aula-15/` em /curso-powerbi/site/aula-15/ e o conteúdo de `site/arquivos/` em /curso-powerbi/site/arquivos/.
