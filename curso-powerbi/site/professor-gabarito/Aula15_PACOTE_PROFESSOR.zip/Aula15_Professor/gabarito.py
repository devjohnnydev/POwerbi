import pandas as pd, numpy as np, json, glob
P='pacote_aluno'
v=pd.concat([pd.read_csv(f,sep=';',dtype=str) for f in sorted(glob.glob(P+'/Vendas/*.csv'))],ignore_index=True)
bruto=len(v)
v=v.drop_duplicates(); dedup=len(v)
v['SKU']=v.SKU.str.strip().str.upper()
v['Data']=pd.to_datetime(v.Data,format='%d/%m/%Y')
for c in ['PrecoUnit','Desconto']: v[c]=v[c].str.replace(',','.').astype(float)
v['Qtd']=v.Qtd.astype(int); v['CodLoja']=v.CodLoja.astype(int)
v=v[v.CodLoja!=99]
pr=pd.read_excel(P+'/Produtos.xlsx',header=3)
v=v.merge(pr[['SKU','Categoria','Marca','CustoUnit','Produto']],on='SKU',how='left')
assert v.CustoUnit.notna().all()
v['Fat']=v.Qtd*v.PrecoUnit*(1-v.Desconto); v['CMV']=v.Qtd*v.CustoUnit
dv=json.load(open(P+'/Devolucoes.json',encoding='utf-8'))['devolucoes']
d=pd.DataFrame([{'pedido':x['pedido'],'data':pd.Timestamp(x['dataDevolucao']),'loja':x['loja'],'valor':sum(i['valorReembolsado'] for i in x['itens'])} for x in dv])
lj=pd.read_csv(P+'/Lojas.txt',sep='\t'); lj=lj[lj.CodLoja!=99].set_index('CodLoja').NomeLoja
G={}
G['linhas_brutas']=bruto; G['duplicatas_removidas']=bruto-dedup
G['linhas_teste_removidas']=int(dedup-len(v)); G['linhas_validas']=len(v)
G['pedidos']=int(v.IDPedido.nunique())
G['clientes_distintos_2026']=int(v[(v.Data.dt.year==2026)&(v.IDCliente.notna())].IDCliente.nunique())
G['linhas_sem_cliente']=int(v.IDCliente.isna().sum())
def tot(y=None):
    a=v if y is None else v[v.Data.dt.year==y]; dd=d if y is None else d[d.data.dt.year==y]
    f=a.Fat.sum(); dev=dd.valor.sum(); liq=f-dev; cmv=a.CMV.sum(); luc=liq-cmv
    return dict(faturamento=round(f,2),devolucoes=round(dev,2),liquido=round(liq,2),cmv=round(cmv,2),lucro=round(luc,2),margem=round(luc/liq,4),pedidos=int(a.IDPedido.nunique()),ticket=round(f/a.IDPedido.nunique(),2),qtd=int(a.Qtd.sum()))
G['total']=tot(); G['2025']=tot(2025); G['2026']=tot(2026)
# YTD ago/26 vs mesmo período 2025
a26=v[v.Data.dt.year==2026]; a25=v[(v.Data.dt.year==2025)&(v.Data.dt.month<=8)]
G['crescimento_ytd']=round(a26.Fat.sum()/a25.Fat.sum()-1,4)
G['fat_ytd_2025_jan_ago']=round(a25.Fat.sum(),2)
m=v.groupby(v.Data.dt.to_period('M')).Fat.sum()
G['fat_ago_2026']=round(m[pd.Period('2026-08')],2); G['fat_ago_2025']=round(m[pd.Period('2025-08')],2)
G['mom_ago_2026']=round(m[pd.Period('2026-08')]/m[pd.Period('2026-07')]-1,4)
G['yoy_ago_2026']=round(m[pd.Period('2026-08')]/m[pd.Period('2025-08')]-1,4)
G['melhor_mes']=[str(m.idxmax()),round(m.max(),2)]
G['por_loja_2026']={lj[k]:round(x,2) for k,x in a26.groupby('CodLoja').Fat.sum().sort_values(ascending=False).items()}
G['por_categoria_2026']={k:round(x,2) for k,x in a26.groupby('Categoria').Fat.sum().sort_values(ascending=False).items()}
lc=a26.groupby('Categoria').apply(lambda g:(g.Fat.sum()-g.CMV.sum())/g.Fat.sum())
G['margem_bruta_categoria_2026']={k:round(x,4) for k,x in lc.sort_values(ascending=False).items()}
top=a26.groupby('Produto').Fat.sum().sort_values(ascending=False).head(5)
G['top5_produtos_2026']={k:round(x,2) for k,x in top.items()}
# metas
mt=pd.read_excel(P+'/Metas_2026.xlsx').melt(id_vars=['CodLoja','Loja'],var_name='Mes',value_name='Meta')
mes={'Jan':1,'Fev':2,'Mar':3,'Abr':4,'Mai':5,'Jun':6,'Jul':7,'Ago':8,'Set':9,'Out':10,'Nov':11,'Dez':12}
mt['m']=mt.Mes.map(mes)
meta_ytd=mt[mt.m<=8].Meta.sum(); G['meta_jan_ago_2026']=int(meta_ytd)
G['atingimento_meta_ytd']=round(a26.Fat.sum()/meta_ytd,4)
ls=a26.groupby('CodLoja').Fat.sum(); ms=mt[mt.m<=8].groupby('CodLoja').Meta.sum()
ate=(ls/ms).sort_values(ascending=False)
G['atingimento_loja']={lj[k]:round(x,4) for k,x in ate.items()}
G['loja_acima_meta']=int((ate>=1).sum())
# setembro
s=pd.read_csv(P+'/Novos_Dados/Vendas_2026_09.csv',sep=';',dtype=str).drop_duplicates()
s['SKU']=s.SKU.str.strip().str.upper(); s=s[s.CodLoja.astype(int)!=99]
s['f']=s.Qtd.astype(int)*s.PrecoUnit.str.replace(',','.').astype(float)*(1-s.Desconto.str.replace(',','.').astype(float))
G['fat_set_2026_novo']=round(s.f.sum(),2); G['fat_total_apos_refresh']=round(G['total']['faturamento']+s.f.sum(),2)
json.dump(G,open('gabarito.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(json.dumps(G,ensure_ascii=False,indent=1))
# cross-check com pickle original
V=pd.read_pickle('vendas_limpas_com_teste.pkl'); V=V[(V.CodLoja!=99)&(V.Data<'2026-09-01')]
print('check fat:', round((V.Qtd*V.PrecoUnit*(1-V.Desconto)).sum(),2), G['total']['faturamento'])
